<?php
defined('_JEXEC') or die('Restricted access');
?>

<div class="j2store-message">
    <h3><?php echo JText::_('PLG_J2STORE_FLUTTERWAVE_MESSAGE_HEADING'); ?></h3>
    <p><?php echo $vars->message; ?></p>
</div>
