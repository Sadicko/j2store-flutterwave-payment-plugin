<?php
defined('_JEXEC') or die('Restricted access');
?>

<div class="j2store-payment-form">
    <h3><?php echo JText::_('PLG_J2STORE_FLUTTERWAVE_FORM_HEADING'); ?></h3>
    <p><?php echo JText::_('PLG_J2STORE_FLUTTERWAVE_FORM_DESCRIPTION'); ?></p>
    <p><?php echo $vars->onselection_text; ?></p>
</div>
