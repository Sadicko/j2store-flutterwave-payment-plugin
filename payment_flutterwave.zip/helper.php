<?php
defined('_JEXEC') or die('Restricted access');

class plgJ2StorePayment_flutterwaveHelper
{
    public static function encrypt($text, $key)
    {
        // Encryption logic here (if needed)
        return $text;
    }
}
